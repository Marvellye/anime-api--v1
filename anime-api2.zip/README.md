# Anime API

### Installing

Clone the Repository and run


```
git clone https://replit.com/@ezekielmarvelly/anime-api?v1
cd Anime-api
npm install 
```
start the server with the following command:
```
npm start
```

Now the server is running on <a href="http://localhost:3000">http://localhost:3000</a>
